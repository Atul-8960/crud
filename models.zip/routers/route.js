const express = require('express');
const router =express.Router();
const user = require('../models/model');


router.get('/', async (req,res) => {

   const details = await user.find();
   if(!details){
       res.status(422).send('no details');
   }
   else{
       res.json(details);
   }

})


router.post('/register', async (req, res) => {

    const {cname, price, dname, dphone} = req.body;
    try{

        const userExists = await user.findOne({price: price, dname: dname, dphone: dphone});
        if(userExists){
            res.status(422).json({ message:"user exists"});
        }
        else{
            const data = new user({ cname, price, dname, dphone});
            await data.save();
            res.status(201).json({ message: "user registetred sucessfully" })
        }

    }
    catch (error) {
        res.status(422).json({ message: "error"});
    }
})

router.get('/:id', async(req, res) => {

try{
    const details = await user.findById(req.params.id);
    if(details){
        res.json(details);
    }
    else{
        res.status(422).json({ message: "no user of the id"})
    }
}
catch (error) {
    res.status(422).json({ message: "error"});
}


})

router.patch('/:id',async (req, res) => {
    const{ cname, price, dname, dphone} = req.body;

    const details = await user.findById(req.params.id);

    if(details){
        details.cname = cname;
        details.price = price;
        details.dname = dname;
        details.dphone = dphone;
        await details.save();
        res.json({ message: "success"});
    }
    

})

module.exports = router


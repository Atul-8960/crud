const mongoose = require('mongoose');

const Userschema = new mongoose.Schema({ 
    cname:{
        type: String,
        required: true
    },
    price:{
        type:Number,
        required: true
    },
    dname:{
        type: String,
        required: true
    },
    dphone:{
        type: Number,
        required: true
    }

})

module.exports = mongoose.model('user',Userschema)
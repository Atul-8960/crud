const express = require('express');
const mongoose = require('mongoose');
const PORT = 3000;
const URL = 'mongodb+srv://user:root@cluster0.2zo3v.mongodb.net/Cluster0?retryWrites=true&w=majority';

const app = express();
mongoose.connect(URL).then(() => {
    console.log('Connecction Successful')
}).catch(err => {console.log(err+'/nconection failed')});

app.use(express.json());

app.use(require('./routers/route'))


app.listen(PORT, () => {
    console.log(`server is working on port ${PORT}`);
})
